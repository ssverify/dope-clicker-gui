﻿using DopeClicker.Core;
using DopeClicker.Core.Randomizations;
using DopeClicker.Core.Settings;
using DopeClicker.UI;
using DopeClicker.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DopeClicker {
    static class Program {

        [STAThread]
        static void Main() {
            //Fix Windows compatibility issue 
            WinApi.TimeBeginPeriod(9U);

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Main(Config.Default));
        }
    }
}
