﻿using DopeClicker.Core;
using DopeClicker.Core.Settings;
using DopeClicker.Utils;
using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DopeClicker.UI {
    partial class Main : Form {
        Config config;
        public Main(Config config) {
            this.config = config;

            InitializeComponent();
            AutoclickerPanel.Parent = this;
            ProfilesPanel.Parent = this;
            SettingsPanel.Parent = this;

            
        }

        #region Sidebar
        private void MinimizeButton_Click(object sender, EventArgs e) {
            this.WindowState = FormWindowState.Minimized;
        }

        private void CloseButton_Click(object sender, EventArgs e) {
            //TODO
        }

        List<string> panels = new List<string> { "Autoclicker", "Profiles", "Settings" };

        private void PanelSwitcher_Click(object sender, EventArgs e) {
            var button = (PictureBox)sender;

            int panelIndex = panels.IndexOf(button.Name.Split(
                new string[] { "Button" }, StringSplitOptions.None)[0]);

            var resourceFields = typeof(Properties.Resources).GetProperties(BindingFlags.NonPublic | BindingFlags.Static);
            var thisFields = this.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic);

            for(int i = 0; i < panels.Count; i++) {

                //Set sidebar images
                string state = i == panelIndex ? "on" : "off";

                var resourceField = resourceFields.Single(f => f.Name == $"{panels[i]}_{state}");
                var thisField = thisFields.Single(f => f.Name == $"{panels[i]}Button");

                ((PictureBox)thisField.GetValue(this)).Image = (Bitmap)resourceField.GetValue(null);

                //Set panel
                var panel = (Panel)thisFields.Single(f => f.Name == $"{panels[i]}Panel").GetValue(this);

                if(i == panelIndex) {
                    panel.Show();
                }
                else {
                    panel.Hide();
                }
            }
        }
        #endregion

        #region Settings

            #region Slots
        private void SlotButton_Click(object sender, EventArgs e) {
            if(!(e is MouseEventArgs args)) {
                return;
            }

            var button = (Guna2Button)sender;
            if (args.Button == MouseButtons.Right) {
                if (WinApi.GetAsyncKeyState((int)Keys.LShiftKey)) {
                    SlotSelectionLabel.Text = $"Press any key to assign it to the slot {button.Name[4]}";
                    SlotSelectionLabel.Focus();
                }
                else {
                    SlotSelectionLabel.Text = $"The current key for this slot is [{KeyboardHelper.FormatKey(config.Slots[int.Parse(button.Name[4].ToString()) - 1].Key)}]";
                }
            }
            else {
                var index = int.Parse(button.Name[4].ToString()) - 1;
                var slot = this.config.Slots[index];

                if (slot.Enable) {
                    button.FillColor = Color.FromArgb(32, 30, 41);
                    button.CustomBorderColor = Color.FromArgb(47, 45, 58);
                }
                else {
                    button.FillColor = Color.FromArgb(36, 36, 43);
                    button.CustomBorderColor = Color.FromArgb(55, 53, 62);
                }

                slot.Enable = !slot.Enable;
            }

            
            ControlHelper.CenterControl(SlotSelectionLabel);
        }

        bool isSelectingSlot = false;
        private void SlotSelectionLabel_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e) {
            if (this.isSelectingSlot || e.KeyCode == Keys.LShiftKey || e.KeyCode == Keys.ShiftKey)
                return;

            this.isSelectingSlot = true;

            

            if (!int.TryParse(SlotSelectionLabel.Text[SlotSelectionLabel.Text.Length - 1].ToString(), out var index)) {
                this.isSelectingSlot = false;
                return;
            }

            index--;

            object button = this.GetType().GetFields(BindingFlags.Instance | BindingFlags.NonPublic)
                .Single(f => f.Name == $"Slot{index + 1}Button").GetValue(this);

            if (e.KeyCode == Keys.Escape) {
                this.isSelectingSlot = false;
                SlotButton_Click(button, new MouseEventArgs(MouseButtons.Right, 1, 0, 0, 0));
                return;
            }

            for (int i = 0; i < this.config.Slots.Length; i++) {
                if (this.config.Slots[i].Key == e.KeyCode && i != index) {
                    Keys key = (Keys)typeof(Keys).GetFields().Single(f => f.Name == $"D{i + 1}").GetValue(null);
                    if (key == e.KeyCode) {
                        this.config.Slots[i].Key = (Keys)typeof(Keys).GetFields().Single(f => f.Name == $"D{index + 1}").GetValue(null);
                    }
                    else {
                        this.config.Slots[i].Key = key;
                    }
                    
                }
            }

            this.config.Slots[index].Key = e.KeyCode;
            SlotButton_Click(button, new MouseEventArgs(MouseButtons.Right, 1, 0, 0, 0));
            this.Focus();
            this.isSelectingSlot = false;
        }
        #endregion

        #endregion
    }
}
