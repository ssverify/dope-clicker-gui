﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dope.Clicker.Controls {
    public class DopeSwitch : CheckBox {
        public DopeSwitch() {
            this.Text = "dp";
        }
        protected override void OnPaint(PaintEventArgs e) {
            this.OnPaintBackground(e);

            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            using (var path = new GraphicsPath()) {
                var d = new Padding(3).All;
                var r = Height - 2 * d;
                path.AddArc(d, d, r, r, 90, 180);
                path.AddArc(40 - r - d, d, r, r, -90, 180);
                path.CloseFigure();
                e.Graphics.FillPath(new SolidBrush(Color.FromArgb(47, 45, 58)), path);
                r = Height - 1;
                var rect = Checked 
                    ? new Rectangle(40 - r - 1, 0, r, r)
                    : new Rectangle(0, 0, r, r);

                e.Graphics.FillEllipse(Checked
                    ? new SolidBrush(Color.FromArgb(63,125,217)) 
                    : new SolidBrush(Color.FromArgb(64,63,72)),
                    rect);
            }
        }
    }
}
