﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dope.Clicker.Controls {
    using System.ComponentModel;
    using System.Drawing;
    using System.Drawing.Drawing2D;
    using System.Windows.Forms;
    public class DopeGroupBox : GroupBox {
        public DopeGroupBox() {
            this.DoubleBuffered = true;
            this.TitleFont = new Font(this.Font.FontFamily, Font.Size + 8, FontStyle.Bold);
        }
        protected override void OnPaint(PaintEventArgs e) {
            var rect = this.ClientRectangle;

            using (var path = GetRoundRectagle(this.ClientRectangle, 15)) {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                rect = new Rectangle(0, 0, rect.Width, TitleFont.Height + Padding.Bottom + Padding.Top);

                using (var brush = new SolidBrush(Color.FromArgb(32, 30, 41)))
                    e.Graphics.FillPath(brush, path);

                var clip = e.Graphics.ClipBounds;
                e.Graphics.SetClip(rect);

                using (var brush = new SolidBrush(Color.FromArgb(23,22,30)))
                    e.Graphics.FillPath(brush, path);

                TextRenderer.DrawText(e.Graphics, Text, TitleFont, rect, Color.FromArgb(228,228,228));
                e.Graphics.SetClip(clip);

                using (var pen = new Pen(Color.FromArgb(47,45,58), 2))
                    e.Graphics.DrawPath(pen, path);
            }
        }
        public Font TitleFont { get; set; }
        private GraphicsPath GetRoundRectagle(Rectangle b, int r) {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(b.X, b.Y, r, r, 180, 90);
            path.AddArc(b.X + b.Width - r - 1, b.Y, r, r, 270, 90);
            path.AddArc(b.X + b.Width - r - 1, b.Y + b.Height - r - 1, r, r, 0, 90);
            path.AddArc(b.X, b.Y + b.Height - r - 1, r, r, 90, 90);
            path.CloseAllFigures();
            return path;
        }
    }
}
