﻿
namespace DopeClicker.UI {
    partial class Main {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.SideBarPanel = new System.Windows.Forms.Panel();
            this.UsernameLabel = new System.Windows.Forms.Label();
            this.LicensedToLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.LogoPictureBox = new System.Windows.Forms.PictureBox();
            this.SettingsButton = new System.Windows.Forms.PictureBox();
            this.ProfilesButton = new System.Windows.Forms.PictureBox();
            this.AutoclickerButton = new System.Windows.Forms.PictureBox();
            this.CloseButton = new Guna.UI2.WinForms.Guna2Button();
            this.MinimizeButton = new Guna.UI2.WinForms.Guna2Button();
            this.SideBarDelimiterPanel = new System.Windows.Forms.Panel();
            this.AutoclickerPanel = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ProfilesPanel = new System.Windows.Forms.Panel();
            this.SettingsPanel = new System.Windows.Forms.Panel();
            this.dopeGroupBox3 = new Dope.Clicker.Controls.DopeGroupBox();
            this.SlotSelectionLabel = new System.Windows.Forms.Label();
            this.Slot9Button = new Guna.UI2.WinForms.Guna2Button();
            this.Slot8Button = new Guna.UI2.WinForms.Guna2Button();
            this.Slot7Button = new Guna.UI2.WinForms.Guna2Button();
            this.Slot6Button = new Guna.UI2.WinForms.Guna2Button();
            this.Slot5Button = new Guna.UI2.WinForms.Guna2Button();
            this.Slot4Button = new Guna.UI2.WinForms.Guna2Button();
            this.Slot3Button = new Guna.UI2.WinForms.Guna2Button();
            this.Slot2Button = new Guna.UI2.WinForms.Guna2Button();
            this.Slot1Button = new Guna.UI2.WinForms.Guna2Button();
            this.dopeGroupBox4 = new Dope.Clicker.Controls.DopeGroupBox();
            this.dopeSwitch3 = new Dope.Clicker.Controls.DopeSwitch();
            this.label19 = new System.Windows.Forms.Label();
            this.guna2Button3 = new Guna.UI2.WinForms.Guna2Button();
            this.dopeGroupBox5 = new Dope.Clicker.Controls.DopeGroupBox();
            this.dopeSwitch4 = new Dope.Clicker.Controls.DopeSwitch();
            this.label20 = new System.Windows.Forms.Label();
            this.guna2Button4 = new Guna.UI2.WinForms.Guna2Button();
            this.GlobalOptionsGroupBox = new Dope.Clicker.Controls.DopeGroupBox();
            this.guna2CustomCheckBox17 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox13 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox14 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox15 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox16 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox12 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox11 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox10 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox9 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.BlockhitLabel = new System.Windows.Forms.Label();
            this.SlotsLabel = new System.Windows.Forms.Label();
            this.ClickSoundsLabel = new System.Windows.Forms.Label();
            this.BlatantModeLabel = new System.Windows.Forms.Label();
            this.OnlyWhilePlayingLabel = new System.Windows.Forms.Label();
            this.AllowWhenShiftingLabel = new System.Windows.Forms.Label();
            this.FirstClickProtectionLabel = new System.Windows.Forms.Label();
            this.CpsDropLabel = new System.Windows.Forms.Label();
            this.SlotsCheckBox = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.BlockhitCheckBox = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.ClickSoundsCheckBox = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.BlatantModeCheckBox = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.OnlyWhilePlayingCheckBox = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.AllowWhenShiftingCheckBox = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.FirstClickProtectionCheckBox = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.CpsDropCheckBox = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.RightClickerGroupBox = new Dope.Clicker.Controls.DopeGroupBox();
            this.RightClickerEnableSwitch = new Dope.Clicker.Controls.DopeSwitch();
            this.RightClickerEnableLabel = new System.Windows.Forms.Label();
            this.RightClickerToggleKeyButton = new Guna.UI2.WinForms.Guna2Button();
            this.LeftClickerGroupBox = new Dope.Clicker.Controls.DopeGroupBox();
            this.LeftClickerEnableSwitch = new Dope.Clicker.Controls.DopeSwitch();
            this.LeftClickerEnableLabel = new System.Windows.Forms.Label();
            this.LeftClickerToggleKeyButton = new Guna.UI2.WinForms.Guna2Button();
            this.dopeGroupBox1 = new Dope.Clicker.Controls.DopeGroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.guna2CustomCheckBox1 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox2 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox3 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox4 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox5 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox6 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox7 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.guna2CustomCheckBox8 = new Guna.UI2.WinForms.Guna2CustomCheckBox();
            this.dopeGroupBox2 = new Dope.Clicker.Controls.DopeGroupBox();
            this.dopeSwitch1 = new Dope.Clicker.Controls.DopeSwitch();
            this.label9 = new System.Windows.Forms.Label();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.dd = new Dope.Clicker.Controls.DopeGroupBox();
            this.dopeSwitch2 = new Dope.Clicker.Controls.DopeSwitch();
            this.label10 = new System.Windows.Forms.Label();
            this.guna2Button2 = new Guna.UI2.WinForms.Guna2Button();
            this.SideBarPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SettingsButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProfilesButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AutoclickerButton)).BeginInit();
            this.AutoclickerPanel.SuspendLayout();
            this.ProfilesPanel.SuspendLayout();
            this.SettingsPanel.SuspendLayout();
            this.dopeGroupBox3.SuspendLayout();
            this.dopeGroupBox4.SuspendLayout();
            this.dopeGroupBox5.SuspendLayout();
            this.GlobalOptionsGroupBox.SuspendLayout();
            this.RightClickerGroupBox.SuspendLayout();
            this.LeftClickerGroupBox.SuspendLayout();
            this.dopeGroupBox1.SuspendLayout();
            this.dopeGroupBox2.SuspendLayout();
            this.dd.SuspendLayout();
            this.SuspendLayout();
            // 
            // SideBarPanel
            // 
            this.SideBarPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.SideBarPanel.Controls.Add(this.UsernameLabel);
            this.SideBarPanel.Controls.Add(this.LicensedToLabel);
            this.SideBarPanel.Controls.Add(this.panel1);
            this.SideBarPanel.Controls.Add(this.LogoPictureBox);
            this.SideBarPanel.Controls.Add(this.SettingsButton);
            this.SideBarPanel.Controls.Add(this.ProfilesButton);
            this.SideBarPanel.Controls.Add(this.AutoclickerButton);
            this.SideBarPanel.Controls.Add(this.CloseButton);
            this.SideBarPanel.Controls.Add(this.MinimizeButton);
            this.SideBarPanel.Location = new System.Drawing.Point(0, 6);
            this.SideBarPanel.Name = "SideBarPanel";
            this.SideBarPanel.Size = new System.Drawing.Size(100, 444);
            this.SideBarPanel.TabIndex = 5;
            // 
            // UsernameLabel
            // 
            this.UsernameLabel.AutoSize = true;
            this.UsernameLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsernameLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.UsernameLabel.Location = new System.Drawing.Point(23, 423);
            this.UsernameLabel.Name = "UsernameLabel";
            this.UsernameLabel.Size = new System.Drawing.Size(55, 16);
            this.UsernameLabel.TabIndex = 18;
            this.UsernameLabel.Text = "Blockhit";
            // 
            // LicensedToLabel
            // 
            this.LicensedToLabel.AutoSize = true;
            this.LicensedToLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LicensedToLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(247)))), ((int)(((byte)(247)))));
            this.LicensedToLabel.Location = new System.Drawing.Point(13, 404);
            this.LicensedToLabel.Name = "LicensedToLabel";
            this.LicensedToLabel.Size = new System.Drawing.Size(75, 16);
            this.LicensedToLabel.TabIndex = 11;
            this.LicensedToLabel.Text = "Licensed to";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.panel1.Location = new System.Drawing.Point(18, 394);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(65, 2);
            this.panel1.TabIndex = 10;
            // 
            // LogoPictureBox
            // 
            this.LogoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("LogoPictureBox.Image")));
            this.LogoPictureBox.Location = new System.Drawing.Point(25, 56);
            this.LogoPictureBox.Name = "LogoPictureBox";
            this.LogoPictureBox.Size = new System.Drawing.Size(50, 50);
            this.LogoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.LogoPictureBox.TabIndex = 9;
            this.LogoPictureBox.TabStop = false;
            // 
            // SettingsButton
            // 
            this.SettingsButton.Image = ((System.Drawing.Image)(resources.GetObject("SettingsButton.Image")));
            this.SettingsButton.Location = new System.Drawing.Point(35, 308);
            this.SettingsButton.Name = "SettingsButton";
            this.SettingsButton.Size = new System.Drawing.Size(30, 30);
            this.SettingsButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SettingsButton.TabIndex = 8;
            this.SettingsButton.TabStop = false;
            this.SettingsButton.Click += new System.EventHandler(this.PanelSwitcher_Click);
            // 
            // ProfilesButton
            // 
            this.ProfilesButton.Image = ((System.Drawing.Image)(resources.GetObject("ProfilesButton.Image")));
            this.ProfilesButton.Location = new System.Drawing.Point(35, 238);
            this.ProfilesButton.Name = "ProfilesButton";
            this.ProfilesButton.Size = new System.Drawing.Size(30, 30);
            this.ProfilesButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ProfilesButton.TabIndex = 7;
            this.ProfilesButton.TabStop = false;
            this.ProfilesButton.Click += new System.EventHandler(this.PanelSwitcher_Click);
            // 
            // AutoclickerButton
            // 
            this.AutoclickerButton.Image = ((System.Drawing.Image)(resources.GetObject("AutoclickerButton.Image")));
            this.AutoclickerButton.Location = new System.Drawing.Point(35, 168);
            this.AutoclickerButton.Name = "AutoclickerButton";
            this.AutoclickerButton.Size = new System.Drawing.Size(30, 30);
            this.AutoclickerButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.AutoclickerButton.TabIndex = 6;
            this.AutoclickerButton.TabStop = false;
            this.AutoclickerButton.Click += new System.EventHandler(this.PanelSwitcher_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.BorderColor = System.Drawing.Color.Transparent;
            this.CloseButton.BorderRadius = 2;
            this.CloseButton.BorderThickness = 2;
            this.CloseButton.CheckedState.Parent = this.CloseButton;
            this.CloseButton.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.CloseButton.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.CloseButton.CustomImages.Parent = this.CloseButton;
            this.CloseButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.CloseButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.CloseButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.CloseButton.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.CloseButton.HoverState.Parent = this.CloseButton;
            this.CloseButton.Location = new System.Drawing.Point(53, 17);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.ShadowDecoration.Parent = this.CloseButton;
            this.CloseButton.Size = new System.Drawing.Size(33, 20);
            this.CloseButton.TabIndex = 5;
            this.CloseButton.Text = "x";
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // MinimizeButton
            // 
            this.MinimizeButton.BorderColor = System.Drawing.Color.Transparent;
            this.MinimizeButton.BorderRadius = 2;
            this.MinimizeButton.BorderThickness = 2;
            this.MinimizeButton.CheckedState.Parent = this.MinimizeButton;
            this.MinimizeButton.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.MinimizeButton.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.MinimizeButton.CustomImages.Parent = this.MinimizeButton;
            this.MinimizeButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.MinimizeButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.MinimizeButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.MinimizeButton.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.MinimizeButton.HoverState.Parent = this.MinimizeButton;
            this.MinimizeButton.Location = new System.Drawing.Point(14, 17);
            this.MinimizeButton.Name = "MinimizeButton";
            this.MinimizeButton.ShadowDecoration.Parent = this.MinimizeButton;
            this.MinimizeButton.Size = new System.Drawing.Size(33, 20);
            this.MinimizeButton.TabIndex = 4;
            this.MinimizeButton.Text = "-";
            this.MinimizeButton.Click += new System.EventHandler(this.MinimizeButton_Click);
            // 
            // SideBarDelimiterPanel
            // 
            this.SideBarDelimiterPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.SideBarDelimiterPanel.Location = new System.Drawing.Point(100, 6);
            this.SideBarDelimiterPanel.Name = "SideBarDelimiterPanel";
            this.SideBarDelimiterPanel.Size = new System.Drawing.Size(2, 444);
            this.SideBarDelimiterPanel.TabIndex = 6;
            // 
            // AutoclickerPanel
            // 
            this.AutoclickerPanel.Controls.Add(this.GlobalOptionsGroupBox);
            this.AutoclickerPanel.Controls.Add(this.RightClickerGroupBox);
            this.AutoclickerPanel.Controls.Add(this.LeftClickerGroupBox);
            this.AutoclickerPanel.Location = new System.Drawing.Point(104, 6);
            this.AutoclickerPanel.Name = "AutoclickerPanel";
            this.AutoclickerPanel.Size = new System.Drawing.Size(696, 444);
            this.AutoclickerPanel.TabIndex = 7;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(94)))), ((int)(((byte)(176)))));
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 6);
            this.panel2.TabIndex = 4;
            // 
            // ProfilesPanel
            // 
            this.ProfilesPanel.Controls.Add(this.dopeGroupBox1);
            this.ProfilesPanel.Controls.Add(this.dopeGroupBox2);
            this.ProfilesPanel.Controls.Add(this.dd);
            this.ProfilesPanel.Location = new System.Drawing.Point(104, 6);
            this.ProfilesPanel.Name = "ProfilesPanel";
            this.ProfilesPanel.Size = new System.Drawing.Size(696, 444);
            this.ProfilesPanel.TabIndex = 8;
            this.ProfilesPanel.Visible = false;
            // 
            // SettingsPanel
            // 
            this.SettingsPanel.Controls.Add(this.dopeGroupBox3);
            this.SettingsPanel.Controls.Add(this.dopeGroupBox4);
            this.SettingsPanel.Controls.Add(this.dopeGroupBox5);
            this.SettingsPanel.Location = new System.Drawing.Point(104, 6);
            this.SettingsPanel.Name = "SettingsPanel";
            this.SettingsPanel.Size = new System.Drawing.Size(696, 444);
            this.SettingsPanel.TabIndex = 9;
            this.SettingsPanel.Visible = false;
            // 
            // dopeGroupBox3
            // 
            this.dopeGroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.dopeGroupBox3.Controls.Add(this.SlotSelectionLabel);
            this.dopeGroupBox3.Controls.Add(this.Slot9Button);
            this.dopeGroupBox3.Controls.Add(this.Slot8Button);
            this.dopeGroupBox3.Controls.Add(this.Slot7Button);
            this.dopeGroupBox3.Controls.Add(this.Slot6Button);
            this.dopeGroupBox3.Controls.Add(this.Slot5Button);
            this.dopeGroupBox3.Controls.Add(this.Slot4Button);
            this.dopeGroupBox3.Controls.Add(this.Slot3Button);
            this.dopeGroupBox3.Controls.Add(this.Slot2Button);
            this.dopeGroupBox3.Controls.Add(this.Slot1Button);
            this.dopeGroupBox3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dopeGroupBox3.Location = new System.Drawing.Point(13, 196);
            this.dopeGroupBox3.Name = "dopeGroupBox3";
            this.dopeGroupBox3.Size = new System.Drawing.Size(325, 112);
            this.dopeGroupBox3.TabIndex = 3;
            this.dopeGroupBox3.TabStop = false;
            this.dopeGroupBox3.Text = "Slots";
            this.dopeGroupBox3.TitleFont = new System.Drawing.Font("Arial", 10F);
            // 
            // SlotSelectionLabel
            // 
            this.SlotSelectionLabel.AutoSize = true;
            this.SlotSelectionLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SlotSelectionLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.SlotSelectionLabel.Location = new System.Drawing.Point(142, 78);
            this.SlotSelectionLabel.Name = "SlotSelectionLabel";
            this.SlotSelectionLabel.Size = new System.Drawing.Size(0, 16);
            this.SlotSelectionLabel.TabIndex = 13;
            this.SlotSelectionLabel.PreviewKeyDown += new System.Windows.Forms.PreviewKeyDownEventHandler(this.SlotSelectionLabel_PreviewKeyDown);
            // 
            // Slot9Button
            // 
            this.Slot9Button.BorderColor = System.Drawing.Color.Transparent;
            this.Slot9Button.BorderRadius = 2;
            this.Slot9Button.BorderThickness = 2;
            this.Slot9Button.CheckedState.Parent = this.Slot9Button;
            this.Slot9Button.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.Slot9Button.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.Slot9Button.CustomImages.Parent = this.Slot9Button;
            this.Slot9Button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.Slot9Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Slot9Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.Slot9Button.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.Slot9Button.HoverState.Parent = this.Slot9Button;
            this.Slot9Button.Location = new System.Drawing.Point(290, 35);
            this.Slot9Button.Name = "Slot9Button";
            this.Slot9Button.ShadowDecoration.Parent = this.Slot9Button;
            this.Slot9Button.Size = new System.Drawing.Size(25, 25);
            this.Slot9Button.TabIndex = 12;
            this.Slot9Button.Text = "9";
            this.Slot9Button.Click += new System.EventHandler(this.SlotButton_Click);
            // 
            // Slot8Button
            // 
            this.Slot8Button.BorderColor = System.Drawing.Color.Transparent;
            this.Slot8Button.BorderRadius = 2;
            this.Slot8Button.BorderThickness = 2;
            this.Slot8Button.CheckedState.Parent = this.Slot8Button;
            this.Slot8Button.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.Slot8Button.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.Slot8Button.CustomImages.Parent = this.Slot8Button;
            this.Slot8Button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.Slot8Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Slot8Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.Slot8Button.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.Slot8Button.HoverState.Parent = this.Slot8Button;
            this.Slot8Button.Location = new System.Drawing.Point(255, 35);
            this.Slot8Button.Name = "Slot8Button";
            this.Slot8Button.ShadowDecoration.Parent = this.Slot8Button;
            this.Slot8Button.Size = new System.Drawing.Size(25, 25);
            this.Slot8Button.TabIndex = 11;
            this.Slot8Button.Text = "8";
            this.Slot8Button.Click += new System.EventHandler(this.SlotButton_Click);
            // 
            // Slot7Button
            // 
            this.Slot7Button.BorderColor = System.Drawing.Color.Transparent;
            this.Slot7Button.BorderRadius = 2;
            this.Slot7Button.BorderThickness = 2;
            this.Slot7Button.CheckedState.Parent = this.Slot7Button;
            this.Slot7Button.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.Slot7Button.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.Slot7Button.CustomImages.Parent = this.Slot7Button;
            this.Slot7Button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.Slot7Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Slot7Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.Slot7Button.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.Slot7Button.HoverState.Parent = this.Slot7Button;
            this.Slot7Button.Location = new System.Drawing.Point(220, 35);
            this.Slot7Button.Name = "Slot7Button";
            this.Slot7Button.ShadowDecoration.Parent = this.Slot7Button;
            this.Slot7Button.Size = new System.Drawing.Size(25, 25);
            this.Slot7Button.TabIndex = 10;
            this.Slot7Button.Text = "7";
            this.Slot7Button.Click += new System.EventHandler(this.SlotButton_Click);
            // 
            // Slot6Button
            // 
            this.Slot6Button.BorderColor = System.Drawing.Color.Transparent;
            this.Slot6Button.BorderRadius = 2;
            this.Slot6Button.BorderThickness = 2;
            this.Slot6Button.CheckedState.Parent = this.Slot6Button;
            this.Slot6Button.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.Slot6Button.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.Slot6Button.CustomImages.Parent = this.Slot6Button;
            this.Slot6Button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.Slot6Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Slot6Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.Slot6Button.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.Slot6Button.HoverState.Parent = this.Slot6Button;
            this.Slot6Button.Location = new System.Drawing.Point(185, 35);
            this.Slot6Button.Name = "Slot6Button";
            this.Slot6Button.ShadowDecoration.Parent = this.Slot6Button;
            this.Slot6Button.Size = new System.Drawing.Size(25, 25);
            this.Slot6Button.TabIndex = 9;
            this.Slot6Button.Text = "6";
            this.Slot6Button.Click += new System.EventHandler(this.SlotButton_Click);
            // 
            // Slot5Button
            // 
            this.Slot5Button.BorderColor = System.Drawing.Color.Transparent;
            this.Slot5Button.BorderRadius = 2;
            this.Slot5Button.BorderThickness = 2;
            this.Slot5Button.CheckedState.Parent = this.Slot5Button;
            this.Slot5Button.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.Slot5Button.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.Slot5Button.CustomImages.Parent = this.Slot5Button;
            this.Slot5Button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.Slot5Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Slot5Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.Slot5Button.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.Slot5Button.HoverState.Parent = this.Slot5Button;
            this.Slot5Button.Location = new System.Drawing.Point(150, 35);
            this.Slot5Button.Name = "Slot5Button";
            this.Slot5Button.ShadowDecoration.Parent = this.Slot5Button;
            this.Slot5Button.Size = new System.Drawing.Size(25, 25);
            this.Slot5Button.TabIndex = 8;
            this.Slot5Button.Text = "5";
            this.Slot5Button.Click += new System.EventHandler(this.SlotButton_Click);
            // 
            // Slot4Button
            // 
            this.Slot4Button.BorderColor = System.Drawing.Color.Transparent;
            this.Slot4Button.BorderRadius = 2;
            this.Slot4Button.BorderThickness = 2;
            this.Slot4Button.CheckedState.Parent = this.Slot4Button;
            this.Slot4Button.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.Slot4Button.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.Slot4Button.CustomImages.Parent = this.Slot4Button;
            this.Slot4Button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.Slot4Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Slot4Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.Slot4Button.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.Slot4Button.HoverState.Parent = this.Slot4Button;
            this.Slot4Button.Location = new System.Drawing.Point(115, 35);
            this.Slot4Button.Name = "Slot4Button";
            this.Slot4Button.ShadowDecoration.Parent = this.Slot4Button;
            this.Slot4Button.Size = new System.Drawing.Size(25, 25);
            this.Slot4Button.TabIndex = 7;
            this.Slot4Button.Text = "4";
            this.Slot4Button.Click += new System.EventHandler(this.SlotButton_Click);
            // 
            // Slot3Button
            // 
            this.Slot3Button.BorderColor = System.Drawing.Color.Transparent;
            this.Slot3Button.BorderRadius = 2;
            this.Slot3Button.BorderThickness = 2;
            this.Slot3Button.CheckedState.Parent = this.Slot3Button;
            this.Slot3Button.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.Slot3Button.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.Slot3Button.CustomImages.Parent = this.Slot3Button;
            this.Slot3Button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.Slot3Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Slot3Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.Slot3Button.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.Slot3Button.HoverState.Parent = this.Slot3Button;
            this.Slot3Button.Location = new System.Drawing.Point(80, 35);
            this.Slot3Button.Name = "Slot3Button";
            this.Slot3Button.ShadowDecoration.Parent = this.Slot3Button;
            this.Slot3Button.Size = new System.Drawing.Size(25, 25);
            this.Slot3Button.TabIndex = 6;
            this.Slot3Button.Text = "3";
            this.Slot3Button.Click += new System.EventHandler(this.SlotButton_Click);
            // 
            // Slot2Button
            // 
            this.Slot2Button.BorderColor = System.Drawing.Color.Transparent;
            this.Slot2Button.BorderRadius = 2;
            this.Slot2Button.BorderThickness = 2;
            this.Slot2Button.CheckedState.Parent = this.Slot2Button;
            this.Slot2Button.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.Slot2Button.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.Slot2Button.CustomImages.Parent = this.Slot2Button;
            this.Slot2Button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.Slot2Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Slot2Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.Slot2Button.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.Slot2Button.HoverState.Parent = this.Slot2Button;
            this.Slot2Button.Location = new System.Drawing.Point(45, 35);
            this.Slot2Button.Name = "Slot2Button";
            this.Slot2Button.ShadowDecoration.Parent = this.Slot2Button;
            this.Slot2Button.Size = new System.Drawing.Size(25, 25);
            this.Slot2Button.TabIndex = 5;
            this.Slot2Button.Text = "2";
            this.Slot2Button.Click += new System.EventHandler(this.SlotButton_Click);
            // 
            // Slot1Button
            // 
            this.Slot1Button.BorderColor = System.Drawing.Color.Transparent;
            this.Slot1Button.BorderRadius = 2;
            this.Slot1Button.BorderThickness = 2;
            this.Slot1Button.CheckedState.Parent = this.Slot1Button;
            this.Slot1Button.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.Slot1Button.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.Slot1Button.CustomImages.Parent = this.Slot1Button;
            this.Slot1Button.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.Slot1Button.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Slot1Button.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.Slot1Button.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.Slot1Button.HoverState.Parent = this.Slot1Button;
            this.Slot1Button.Location = new System.Drawing.Point(10, 35);
            this.Slot1Button.Name = "Slot1Button";
            this.Slot1Button.ShadowDecoration.Parent = this.Slot1Button;
            this.Slot1Button.Size = new System.Drawing.Size(25, 25);
            this.Slot1Button.TabIndex = 4;
            this.Slot1Button.Text = "1";
            this.Slot1Button.Click += new System.EventHandler(this.SlotButton_Click);
            // 
            // dopeGroupBox4
            // 
            this.dopeGroupBox4.BackColor = System.Drawing.Color.Transparent;
            this.dopeGroupBox4.Controls.Add(this.dopeSwitch3);
            this.dopeGroupBox4.Controls.Add(this.label19);
            this.dopeGroupBox4.Controls.Add(this.guna2Button3);
            this.dopeGroupBox4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dopeGroupBox4.Location = new System.Drawing.Point(359, 12);
            this.dopeGroupBox4.Name = "dopeGroupBox4";
            this.dopeGroupBox4.Size = new System.Drawing.Size(325, 175);
            this.dopeGroupBox4.TabIndex = 2;
            this.dopeGroupBox4.TabStop = false;
            this.dopeGroupBox4.Text = "Right clicker";
            this.dopeGroupBox4.TitleFont = new System.Drawing.Font("Arial", 10F);
            // 
            // dopeSwitch3
            // 
            this.dopeSwitch3.AutoSize = true;
            this.dopeSwitch3.Location = new System.Drawing.Point(275, 28);
            this.dopeSwitch3.Name = "dopeSwitch3";
            this.dopeSwitch3.Size = new System.Drawing.Size(40, 18);
            this.dopeSwitch3.TabIndex = 14;
            this.dopeSwitch3.Text = "dp";
            this.dopeSwitch3.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label19.Location = new System.Drawing.Point(6, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(48, 16);
            this.label19.TabIndex = 13;
            this.label19.Text = "Enable";
            // 
            // guna2Button3
            // 
            this.guna2Button3.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button3.BorderRadius = 2;
            this.guna2Button3.BorderThickness = 2;
            this.guna2Button3.CheckedState.Parent = this.guna2Button3;
            this.guna2Button3.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2Button3.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.guna2Button3.CustomImages.Parent = this.guna2Button3;
            this.guna2Button3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2Button3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.guna2Button3.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.guna2Button3.HoverState.Parent = this.guna2Button3;
            this.guna2Button3.Location = new System.Drawing.Point(273, 144);
            this.guna2Button3.Name = "guna2Button3";
            this.guna2Button3.ShadowDecoration.Parent = this.guna2Button3;
            this.guna2Button3.Size = new System.Drawing.Size(46, 25);
            this.guna2Button3.TabIndex = 4;
            this.guna2Button3.Text = "None";
            // 
            // dopeGroupBox5
            // 
            this.dopeGroupBox5.BackColor = System.Drawing.Color.Transparent;
            this.dopeGroupBox5.Controls.Add(this.dopeSwitch4);
            this.dopeGroupBox5.Controls.Add(this.label20);
            this.dopeGroupBox5.Controls.Add(this.guna2Button4);
            this.dopeGroupBox5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dopeGroupBox5.Location = new System.Drawing.Point(13, 12);
            this.dopeGroupBox5.Name = "dopeGroupBox5";
            this.dopeGroupBox5.Size = new System.Drawing.Size(325, 175);
            this.dopeGroupBox5.TabIndex = 1;
            this.dopeGroupBox5.TabStop = false;
            this.dopeGroupBox5.Text = "dopeGroupBox5";
            this.dopeGroupBox5.TitleFont = new System.Drawing.Font("Arial", 10F);
            // 
            // dopeSwitch4
            // 
            this.dopeSwitch4.AutoSize = true;
            this.dopeSwitch4.Location = new System.Drawing.Point(275, 28);
            this.dopeSwitch4.Name = "dopeSwitch4";
            this.dopeSwitch4.Size = new System.Drawing.Size(40, 18);
            this.dopeSwitch4.TabIndex = 12;
            this.dopeSwitch4.Text = "dp";
            this.dopeSwitch4.UseVisualStyleBackColor = true;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label20.Location = new System.Drawing.Point(8, 28);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(48, 16);
            this.label20.TabIndex = 11;
            this.label20.Text = "Enable";
            // 
            // guna2Button4
            // 
            this.guna2Button4.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button4.BorderRadius = 2;
            this.guna2Button4.BorderThickness = 2;
            this.guna2Button4.CheckedState.Parent = this.guna2Button4;
            this.guna2Button4.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2Button4.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.guna2Button4.CustomImages.Parent = this.guna2Button4;
            this.guna2Button4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2Button4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.guna2Button4.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.guna2Button4.HoverState.Parent = this.guna2Button4;
            this.guna2Button4.Location = new System.Drawing.Point(273, 144);
            this.guna2Button4.Name = "guna2Button4";
            this.guna2Button4.ShadowDecoration.Parent = this.guna2Button4;
            this.guna2Button4.Size = new System.Drawing.Size(46, 25);
            this.guna2Button4.TabIndex = 3;
            this.guna2Button4.Text = "None";
            // 
            // GlobalOptionsGroupBox
            // 
            this.GlobalOptionsGroupBox.BackColor = System.Drawing.Color.Transparent;
            this.GlobalOptionsGroupBox.Controls.Add(this.guna2CustomCheckBox17);
            this.GlobalOptionsGroupBox.Controls.Add(this.guna2CustomCheckBox13);
            this.GlobalOptionsGroupBox.Controls.Add(this.guna2CustomCheckBox14);
            this.GlobalOptionsGroupBox.Controls.Add(this.guna2CustomCheckBox15);
            this.GlobalOptionsGroupBox.Controls.Add(this.guna2CustomCheckBox16);
            this.GlobalOptionsGroupBox.Controls.Add(this.guna2CustomCheckBox12);
            this.GlobalOptionsGroupBox.Controls.Add(this.guna2CustomCheckBox11);
            this.GlobalOptionsGroupBox.Controls.Add(this.guna2CustomCheckBox10);
            this.GlobalOptionsGroupBox.Controls.Add(this.guna2CustomCheckBox9);
            this.GlobalOptionsGroupBox.Controls.Add(this.BlockhitLabel);
            this.GlobalOptionsGroupBox.Controls.Add(this.SlotsLabel);
            this.GlobalOptionsGroupBox.Controls.Add(this.ClickSoundsLabel);
            this.GlobalOptionsGroupBox.Controls.Add(this.BlatantModeLabel);
            this.GlobalOptionsGroupBox.Controls.Add(this.OnlyWhilePlayingLabel);
            this.GlobalOptionsGroupBox.Controls.Add(this.AllowWhenShiftingLabel);
            this.GlobalOptionsGroupBox.Controls.Add(this.FirstClickProtectionLabel);
            this.GlobalOptionsGroupBox.Controls.Add(this.CpsDropLabel);
            this.GlobalOptionsGroupBox.Controls.Add(this.SlotsCheckBox);
            this.GlobalOptionsGroupBox.Controls.Add(this.BlockhitCheckBox);
            this.GlobalOptionsGroupBox.Controls.Add(this.ClickSoundsCheckBox);
            this.GlobalOptionsGroupBox.Controls.Add(this.BlatantModeCheckBox);
            this.GlobalOptionsGroupBox.Controls.Add(this.OnlyWhilePlayingCheckBox);
            this.GlobalOptionsGroupBox.Controls.Add(this.AllowWhenShiftingCheckBox);
            this.GlobalOptionsGroupBox.Controls.Add(this.FirstClickProtectionCheckBox);
            this.GlobalOptionsGroupBox.Controls.Add(this.CpsDropCheckBox);
            this.GlobalOptionsGroupBox.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GlobalOptionsGroupBox.Location = new System.Drawing.Point(13, 197);
            this.GlobalOptionsGroupBox.Name = "GlobalOptionsGroupBox";
            this.GlobalOptionsGroupBox.Size = new System.Drawing.Size(325, 235);
            this.GlobalOptionsGroupBox.TabIndex = 3;
            this.GlobalOptionsGroupBox.TabStop = false;
            this.GlobalOptionsGroupBox.Text = "Global Options";
            this.GlobalOptionsGroupBox.TitleFont = new System.Drawing.Font("Arial", 10F);
            // 
            // guna2CustomCheckBox17
            // 
            this.guna2CustomCheckBox17.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox17.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox17.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox17.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox17.CheckedState.Parent = this.guna2CustomCheckBox17;
            this.guna2CustomCheckBox17.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox17.Location = new System.Drawing.Point(299, 208);
            this.guna2CustomCheckBox17.Name = "guna2CustomCheckBox17";
            this.guna2CustomCheckBox17.ShadowDecoration.Parent = this.guna2CustomCheckBox17;
            this.guna2CustomCheckBox17.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox17.TabIndex = 26;
            this.guna2CustomCheckBox17.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox17.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox17.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox17.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox17.UncheckedState.Parent = this.guna2CustomCheckBox17;
            // 
            // guna2CustomCheckBox13
            // 
            this.guna2CustomCheckBox13.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox13.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox13.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox13.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox13.CheckedState.Parent = this.guna2CustomCheckBox13;
            this.guna2CustomCheckBox13.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox13.Location = new System.Drawing.Point(273, 208);
            this.guna2CustomCheckBox13.Name = "guna2CustomCheckBox13";
            this.guna2CustomCheckBox13.ShadowDecoration.Parent = this.guna2CustomCheckBox13;
            this.guna2CustomCheckBox13.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox13.TabIndex = 25;
            this.guna2CustomCheckBox13.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox13.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox13.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox13.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox13.UncheckedState.Parent = this.guna2CustomCheckBox13;
            // 
            // guna2CustomCheckBox14
            // 
            this.guna2CustomCheckBox14.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox14.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox14.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox14.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox14.CheckedState.Parent = this.guna2CustomCheckBox14;
            this.guna2CustomCheckBox14.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox14.Location = new System.Drawing.Point(249, 208);
            this.guna2CustomCheckBox14.Name = "guna2CustomCheckBox14";
            this.guna2CustomCheckBox14.ShadowDecoration.Parent = this.guna2CustomCheckBox14;
            this.guna2CustomCheckBox14.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox14.TabIndex = 24;
            this.guna2CustomCheckBox14.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox14.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox14.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox14.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox14.UncheckedState.Parent = this.guna2CustomCheckBox14;
            // 
            // guna2CustomCheckBox15
            // 
            this.guna2CustomCheckBox15.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox15.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox15.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox15.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox15.CheckedState.Parent = this.guna2CustomCheckBox15;
            this.guna2CustomCheckBox15.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox15.Location = new System.Drawing.Point(223, 208);
            this.guna2CustomCheckBox15.Name = "guna2CustomCheckBox15";
            this.guna2CustomCheckBox15.ShadowDecoration.Parent = this.guna2CustomCheckBox15;
            this.guna2CustomCheckBox15.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox15.TabIndex = 23;
            this.guna2CustomCheckBox15.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox15.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox15.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox15.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox15.UncheckedState.Parent = this.guna2CustomCheckBox15;
            // 
            // guna2CustomCheckBox16
            // 
            this.guna2CustomCheckBox16.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox16.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox16.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox16.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox16.CheckedState.Parent = this.guna2CustomCheckBox16;
            this.guna2CustomCheckBox16.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox16.Location = new System.Drawing.Point(197, 208);
            this.guna2CustomCheckBox16.Name = "guna2CustomCheckBox16";
            this.guna2CustomCheckBox16.ShadowDecoration.Parent = this.guna2CustomCheckBox16;
            this.guna2CustomCheckBox16.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox16.TabIndex = 22;
            this.guna2CustomCheckBox16.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox16.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox16.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox16.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox16.UncheckedState.Parent = this.guna2CustomCheckBox16;
            // 
            // guna2CustomCheckBox12
            // 
            this.guna2CustomCheckBox12.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox12.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox12.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox12.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox12.CheckedState.Parent = this.guna2CustomCheckBox12;
            this.guna2CustomCheckBox12.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox12.Location = new System.Drawing.Point(171, 208);
            this.guna2CustomCheckBox12.Name = "guna2CustomCheckBox12";
            this.guna2CustomCheckBox12.ShadowDecoration.Parent = this.guna2CustomCheckBox12;
            this.guna2CustomCheckBox12.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox12.TabIndex = 21;
            this.guna2CustomCheckBox12.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox12.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox12.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox12.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox12.UncheckedState.Parent = this.guna2CustomCheckBox12;
            // 
            // guna2CustomCheckBox11
            // 
            this.guna2CustomCheckBox11.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox11.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox11.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox11.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox11.CheckedState.Parent = this.guna2CustomCheckBox11;
            this.guna2CustomCheckBox11.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox11.Location = new System.Drawing.Point(145, 208);
            this.guna2CustomCheckBox11.Name = "guna2CustomCheckBox11";
            this.guna2CustomCheckBox11.ShadowDecoration.Parent = this.guna2CustomCheckBox11;
            this.guna2CustomCheckBox11.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox11.TabIndex = 20;
            this.guna2CustomCheckBox11.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox11.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox11.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox11.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox11.UncheckedState.Parent = this.guna2CustomCheckBox11;
            // 
            // guna2CustomCheckBox10
            // 
            this.guna2CustomCheckBox10.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox10.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox10.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox10.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox10.CheckedState.Parent = this.guna2CustomCheckBox10;
            this.guna2CustomCheckBox10.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox10.Location = new System.Drawing.Point(119, 208);
            this.guna2CustomCheckBox10.Name = "guna2CustomCheckBox10";
            this.guna2CustomCheckBox10.ShadowDecoration.Parent = this.guna2CustomCheckBox10;
            this.guna2CustomCheckBox10.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox10.TabIndex = 19;
            this.guna2CustomCheckBox10.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox10.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox10.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox10.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox10.UncheckedState.Parent = this.guna2CustomCheckBox10;
            // 
            // guna2CustomCheckBox9
            // 
            this.guna2CustomCheckBox9.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox9.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox9.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox9.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox9.CheckedState.Parent = this.guna2CustomCheckBox9;
            this.guna2CustomCheckBox9.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox9.Location = new System.Drawing.Point(93, 208);
            this.guna2CustomCheckBox9.Name = "guna2CustomCheckBox9";
            this.guna2CustomCheckBox9.ShadowDecoration.Parent = this.guna2CustomCheckBox9;
            this.guna2CustomCheckBox9.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox9.TabIndex = 18;
            this.guna2CustomCheckBox9.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox9.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox9.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox9.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox9.UncheckedState.Parent = this.guna2CustomCheckBox9;
            // 
            // BlockhitLabel
            // 
            this.BlockhitLabel.AutoSize = true;
            this.BlockhitLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlockhitLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.BlockhitLabel.Location = new System.Drawing.Point(32, 184);
            this.BlockhitLabel.Name = "BlockhitLabel";
            this.BlockhitLabel.Size = new System.Drawing.Size(55, 16);
            this.BlockhitLabel.TabIndex = 17;
            this.BlockhitLabel.Text = "Blockhit";
            // 
            // SlotsLabel
            // 
            this.SlotsLabel.AutoSize = true;
            this.SlotsLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SlotsLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.SlotsLabel.Location = new System.Drawing.Point(32, 210);
            this.SlotsLabel.Name = "SlotsLabel";
            this.SlotsLabel.Size = new System.Drawing.Size(38, 16);
            this.SlotsLabel.TabIndex = 16;
            this.SlotsLabel.Text = "Slots";
            // 
            // ClickSoundsLabel
            // 
            this.ClickSoundsLabel.AutoSize = true;
            this.ClickSoundsLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClickSoundsLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.ClickSoundsLabel.Location = new System.Drawing.Point(32, 158);
            this.ClickSoundsLabel.Name = "ClickSoundsLabel";
            this.ClickSoundsLabel.Size = new System.Drawing.Size(83, 16);
            this.ClickSoundsLabel.TabIndex = 15;
            this.ClickSoundsLabel.Text = "Click sounds";
            // 
            // BlatantModeLabel
            // 
            this.BlatantModeLabel.AutoSize = true;
            this.BlatantModeLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BlatantModeLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.BlatantModeLabel.Location = new System.Drawing.Point(32, 132);
            this.BlatantModeLabel.Name = "BlatantModeLabel";
            this.BlatantModeLabel.Size = new System.Drawing.Size(85, 16);
            this.BlatantModeLabel.TabIndex = 14;
            this.BlatantModeLabel.Text = "Blatant mode";
            // 
            // OnlyWhilePlayingLabel
            // 
            this.OnlyWhilePlayingLabel.AutoSize = true;
            this.OnlyWhilePlayingLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OnlyWhilePlayingLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.OnlyWhilePlayingLabel.Location = new System.Drawing.Point(32, 106);
            this.OnlyWhilePlayingLabel.Name = "OnlyWhilePlayingLabel";
            this.OnlyWhilePlayingLabel.Size = new System.Drawing.Size(113, 16);
            this.OnlyWhilePlayingLabel.TabIndex = 13;
            this.OnlyWhilePlayingLabel.Text = "Only while playing";
            // 
            // AllowWhenShiftingLabel
            // 
            this.AllowWhenShiftingLabel.AutoSize = true;
            this.AllowWhenShiftingLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllowWhenShiftingLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.AllowWhenShiftingLabel.Location = new System.Drawing.Point(32, 80);
            this.AllowWhenShiftingLabel.Name = "AllowWhenShiftingLabel";
            this.AllowWhenShiftingLabel.Size = new System.Drawing.Size(118, 16);
            this.AllowWhenShiftingLabel.TabIndex = 12;
            this.AllowWhenShiftingLabel.Text = "Allow when shifting";
            // 
            // FirstClickProtectionLabel
            // 
            this.FirstClickProtectionLabel.AutoSize = true;
            this.FirstClickProtectionLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstClickProtectionLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.FirstClickProtectionLabel.Location = new System.Drawing.Point(32, 54);
            this.FirstClickProtectionLabel.Name = "FirstClickProtectionLabel";
            this.FirstClickProtectionLabel.Size = new System.Drawing.Size(126, 16);
            this.FirstClickProtectionLabel.TabIndex = 11;
            this.FirstClickProtectionLabel.Text = "First click protection";
            // 
            // CpsDropLabel
            // 
            this.CpsDropLabel.AutoSize = true;
            this.CpsDropLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CpsDropLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.CpsDropLabel.Location = new System.Drawing.Point(32, 28);
            this.CpsDropLabel.Name = "CpsDropLabel";
            this.CpsDropLabel.Size = new System.Drawing.Size(62, 16);
            this.CpsDropLabel.TabIndex = 10;
            this.CpsDropLabel.Text = "Cps Drop";
            // 
            // SlotsCheckBox
            // 
            this.SlotsCheckBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.SlotsCheckBox.CheckedState.BorderRadius = 1;
            this.SlotsCheckBox.CheckedState.BorderThickness = 2;
            this.SlotsCheckBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.SlotsCheckBox.CheckedState.Parent = this.SlotsCheckBox;
            this.SlotsCheckBox.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.SlotsCheckBox.Location = new System.Drawing.Point(6, 208);
            this.SlotsCheckBox.Name = "SlotsCheckBox";
            this.SlotsCheckBox.ShadowDecoration.Parent = this.SlotsCheckBox;
            this.SlotsCheckBox.Size = new System.Drawing.Size(20, 20);
            this.SlotsCheckBox.TabIndex = 9;
            this.SlotsCheckBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.SlotsCheckBox.UncheckedState.BorderRadius = 2;
            this.SlotsCheckBox.UncheckedState.BorderThickness = 2;
            this.SlotsCheckBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.SlotsCheckBox.UncheckedState.Parent = this.SlotsCheckBox;
            // 
            // BlockhitCheckBox
            // 
            this.BlockhitCheckBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.BlockhitCheckBox.CheckedState.BorderRadius = 1;
            this.BlockhitCheckBox.CheckedState.BorderThickness = 2;
            this.BlockhitCheckBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.BlockhitCheckBox.CheckedState.Parent = this.BlockhitCheckBox;
            this.BlockhitCheckBox.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.BlockhitCheckBox.Location = new System.Drawing.Point(6, 182);
            this.BlockhitCheckBox.Name = "BlockhitCheckBox";
            this.BlockhitCheckBox.ShadowDecoration.Parent = this.BlockhitCheckBox;
            this.BlockhitCheckBox.Size = new System.Drawing.Size(20, 20);
            this.BlockhitCheckBox.TabIndex = 8;
            this.BlockhitCheckBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.BlockhitCheckBox.UncheckedState.BorderRadius = 2;
            this.BlockhitCheckBox.UncheckedState.BorderThickness = 2;
            this.BlockhitCheckBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.BlockhitCheckBox.UncheckedState.Parent = this.BlockhitCheckBox;
            // 
            // ClickSoundsCheckBox
            // 
            this.ClickSoundsCheckBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.ClickSoundsCheckBox.CheckedState.BorderRadius = 1;
            this.ClickSoundsCheckBox.CheckedState.BorderThickness = 2;
            this.ClickSoundsCheckBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.ClickSoundsCheckBox.CheckedState.Parent = this.ClickSoundsCheckBox;
            this.ClickSoundsCheckBox.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.ClickSoundsCheckBox.Location = new System.Drawing.Point(6, 156);
            this.ClickSoundsCheckBox.Name = "ClickSoundsCheckBox";
            this.ClickSoundsCheckBox.ShadowDecoration.Parent = this.ClickSoundsCheckBox;
            this.ClickSoundsCheckBox.Size = new System.Drawing.Size(20, 20);
            this.ClickSoundsCheckBox.TabIndex = 7;
            this.ClickSoundsCheckBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.ClickSoundsCheckBox.UncheckedState.BorderRadius = 2;
            this.ClickSoundsCheckBox.UncheckedState.BorderThickness = 2;
            this.ClickSoundsCheckBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.ClickSoundsCheckBox.UncheckedState.Parent = this.ClickSoundsCheckBox;
            // 
            // BlatantModeCheckBox
            // 
            this.BlatantModeCheckBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.BlatantModeCheckBox.CheckedState.BorderRadius = 1;
            this.BlatantModeCheckBox.CheckedState.BorderThickness = 2;
            this.BlatantModeCheckBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.BlatantModeCheckBox.CheckedState.Parent = this.BlatantModeCheckBox;
            this.BlatantModeCheckBox.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.BlatantModeCheckBox.Location = new System.Drawing.Point(6, 130);
            this.BlatantModeCheckBox.Name = "BlatantModeCheckBox";
            this.BlatantModeCheckBox.ShadowDecoration.Parent = this.BlatantModeCheckBox;
            this.BlatantModeCheckBox.Size = new System.Drawing.Size(20, 20);
            this.BlatantModeCheckBox.TabIndex = 6;
            this.BlatantModeCheckBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.BlatantModeCheckBox.UncheckedState.BorderRadius = 2;
            this.BlatantModeCheckBox.UncheckedState.BorderThickness = 2;
            this.BlatantModeCheckBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.BlatantModeCheckBox.UncheckedState.Parent = this.BlatantModeCheckBox;
            // 
            // OnlyWhilePlayingCheckBox
            // 
            this.OnlyWhilePlayingCheckBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.OnlyWhilePlayingCheckBox.CheckedState.BorderRadius = 1;
            this.OnlyWhilePlayingCheckBox.CheckedState.BorderThickness = 2;
            this.OnlyWhilePlayingCheckBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.OnlyWhilePlayingCheckBox.CheckedState.Parent = this.OnlyWhilePlayingCheckBox;
            this.OnlyWhilePlayingCheckBox.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.OnlyWhilePlayingCheckBox.Location = new System.Drawing.Point(6, 104);
            this.OnlyWhilePlayingCheckBox.Name = "OnlyWhilePlayingCheckBox";
            this.OnlyWhilePlayingCheckBox.ShadowDecoration.Parent = this.OnlyWhilePlayingCheckBox;
            this.OnlyWhilePlayingCheckBox.Size = new System.Drawing.Size(20, 20);
            this.OnlyWhilePlayingCheckBox.TabIndex = 5;
            this.OnlyWhilePlayingCheckBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.OnlyWhilePlayingCheckBox.UncheckedState.BorderRadius = 2;
            this.OnlyWhilePlayingCheckBox.UncheckedState.BorderThickness = 2;
            this.OnlyWhilePlayingCheckBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.OnlyWhilePlayingCheckBox.UncheckedState.Parent = this.OnlyWhilePlayingCheckBox;
            // 
            // AllowWhenShiftingCheckBox
            // 
            this.AllowWhenShiftingCheckBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.AllowWhenShiftingCheckBox.CheckedState.BorderRadius = 1;
            this.AllowWhenShiftingCheckBox.CheckedState.BorderThickness = 2;
            this.AllowWhenShiftingCheckBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.AllowWhenShiftingCheckBox.CheckedState.Parent = this.AllowWhenShiftingCheckBox;
            this.AllowWhenShiftingCheckBox.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.AllowWhenShiftingCheckBox.Location = new System.Drawing.Point(6, 78);
            this.AllowWhenShiftingCheckBox.Name = "AllowWhenShiftingCheckBox";
            this.AllowWhenShiftingCheckBox.ShadowDecoration.Parent = this.AllowWhenShiftingCheckBox;
            this.AllowWhenShiftingCheckBox.Size = new System.Drawing.Size(20, 20);
            this.AllowWhenShiftingCheckBox.TabIndex = 4;
            this.AllowWhenShiftingCheckBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.AllowWhenShiftingCheckBox.UncheckedState.BorderRadius = 2;
            this.AllowWhenShiftingCheckBox.UncheckedState.BorderThickness = 2;
            this.AllowWhenShiftingCheckBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.AllowWhenShiftingCheckBox.UncheckedState.Parent = this.AllowWhenShiftingCheckBox;
            // 
            // FirstClickProtectionCheckBox
            // 
            this.FirstClickProtectionCheckBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.FirstClickProtectionCheckBox.CheckedState.BorderRadius = 1;
            this.FirstClickProtectionCheckBox.CheckedState.BorderThickness = 2;
            this.FirstClickProtectionCheckBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.FirstClickProtectionCheckBox.CheckedState.Parent = this.FirstClickProtectionCheckBox;
            this.FirstClickProtectionCheckBox.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.FirstClickProtectionCheckBox.Location = new System.Drawing.Point(6, 52);
            this.FirstClickProtectionCheckBox.Name = "FirstClickProtectionCheckBox";
            this.FirstClickProtectionCheckBox.ShadowDecoration.Parent = this.FirstClickProtectionCheckBox;
            this.FirstClickProtectionCheckBox.Size = new System.Drawing.Size(20, 20);
            this.FirstClickProtectionCheckBox.TabIndex = 3;
            this.FirstClickProtectionCheckBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.FirstClickProtectionCheckBox.UncheckedState.BorderRadius = 2;
            this.FirstClickProtectionCheckBox.UncheckedState.BorderThickness = 2;
            this.FirstClickProtectionCheckBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.FirstClickProtectionCheckBox.UncheckedState.Parent = this.FirstClickProtectionCheckBox;
            // 
            // CpsDropCheckBox
            // 
            this.CpsDropCheckBox.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.CpsDropCheckBox.CheckedState.BorderRadius = 1;
            this.CpsDropCheckBox.CheckedState.BorderThickness = 2;
            this.CpsDropCheckBox.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.CpsDropCheckBox.CheckedState.Parent = this.CpsDropCheckBox;
            this.CpsDropCheckBox.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.CpsDropCheckBox.Location = new System.Drawing.Point(6, 26);
            this.CpsDropCheckBox.Name = "CpsDropCheckBox";
            this.CpsDropCheckBox.ShadowDecoration.Parent = this.CpsDropCheckBox;
            this.CpsDropCheckBox.Size = new System.Drawing.Size(20, 20);
            this.CpsDropCheckBox.TabIndex = 2;
            this.CpsDropCheckBox.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.CpsDropCheckBox.UncheckedState.BorderRadius = 2;
            this.CpsDropCheckBox.UncheckedState.BorderThickness = 2;
            this.CpsDropCheckBox.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.CpsDropCheckBox.UncheckedState.Parent = this.CpsDropCheckBox;
            // 
            // RightClickerGroupBox
            // 
            this.RightClickerGroupBox.BackColor = System.Drawing.Color.Transparent;
            this.RightClickerGroupBox.Controls.Add(this.RightClickerEnableSwitch);
            this.RightClickerGroupBox.Controls.Add(this.RightClickerEnableLabel);
            this.RightClickerGroupBox.Controls.Add(this.RightClickerToggleKeyButton);
            this.RightClickerGroupBox.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RightClickerGroupBox.Location = new System.Drawing.Point(359, 12);
            this.RightClickerGroupBox.Name = "RightClickerGroupBox";
            this.RightClickerGroupBox.Size = new System.Drawing.Size(325, 175);
            this.RightClickerGroupBox.TabIndex = 2;
            this.RightClickerGroupBox.TabStop = false;
            this.RightClickerGroupBox.Text = "Right clicker";
            this.RightClickerGroupBox.TitleFont = new System.Drawing.Font("Arial", 10F);
            // 
            // RightClickerEnableSwitch
            // 
            this.RightClickerEnableSwitch.AutoSize = true;
            this.RightClickerEnableSwitch.Location = new System.Drawing.Point(275, 28);
            this.RightClickerEnableSwitch.Name = "RightClickerEnableSwitch";
            this.RightClickerEnableSwitch.Size = new System.Drawing.Size(40, 18);
            this.RightClickerEnableSwitch.TabIndex = 14;
            this.RightClickerEnableSwitch.Text = "dp";
            this.RightClickerEnableSwitch.UseVisualStyleBackColor = true;
            // 
            // RightClickerEnableLabel
            // 
            this.RightClickerEnableLabel.AutoSize = true;
            this.RightClickerEnableLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RightClickerEnableLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.RightClickerEnableLabel.Location = new System.Drawing.Point(6, 28);
            this.RightClickerEnableLabel.Name = "RightClickerEnableLabel";
            this.RightClickerEnableLabel.Size = new System.Drawing.Size(48, 16);
            this.RightClickerEnableLabel.TabIndex = 13;
            this.RightClickerEnableLabel.Text = "Enable";
            // 
            // RightClickerToggleKeyButton
            // 
            this.RightClickerToggleKeyButton.BorderColor = System.Drawing.Color.Transparent;
            this.RightClickerToggleKeyButton.BorderRadius = 2;
            this.RightClickerToggleKeyButton.BorderThickness = 2;
            this.RightClickerToggleKeyButton.CheckedState.Parent = this.RightClickerToggleKeyButton;
            this.RightClickerToggleKeyButton.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.RightClickerToggleKeyButton.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.RightClickerToggleKeyButton.CustomImages.Parent = this.RightClickerToggleKeyButton;
            this.RightClickerToggleKeyButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.RightClickerToggleKeyButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.RightClickerToggleKeyButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.RightClickerToggleKeyButton.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.RightClickerToggleKeyButton.HoverState.Parent = this.RightClickerToggleKeyButton;
            this.RightClickerToggleKeyButton.Location = new System.Drawing.Point(273, 144);
            this.RightClickerToggleKeyButton.Name = "RightClickerToggleKeyButton";
            this.RightClickerToggleKeyButton.ShadowDecoration.Parent = this.RightClickerToggleKeyButton;
            this.RightClickerToggleKeyButton.Size = new System.Drawing.Size(46, 25);
            this.RightClickerToggleKeyButton.TabIndex = 4;
            this.RightClickerToggleKeyButton.Text = "None";
            // 
            // LeftClickerGroupBox
            // 
            this.LeftClickerGroupBox.BackColor = System.Drawing.Color.Transparent;
            this.LeftClickerGroupBox.Controls.Add(this.LeftClickerEnableSwitch);
            this.LeftClickerGroupBox.Controls.Add(this.LeftClickerEnableLabel);
            this.LeftClickerGroupBox.Controls.Add(this.LeftClickerToggleKeyButton);
            this.LeftClickerGroupBox.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeftClickerGroupBox.Location = new System.Drawing.Point(13, 12);
            this.LeftClickerGroupBox.Name = "LeftClickerGroupBox";
            this.LeftClickerGroupBox.Size = new System.Drawing.Size(325, 175);
            this.LeftClickerGroupBox.TabIndex = 1;
            this.LeftClickerGroupBox.TabStop = false;
            this.LeftClickerGroupBox.Text = "Left Clicker";
            this.LeftClickerGroupBox.TitleFont = new System.Drawing.Font("Arial", 10F);
            // 
            // LeftClickerEnableSwitch
            // 
            this.LeftClickerEnableSwitch.AutoSize = true;
            this.LeftClickerEnableSwitch.Location = new System.Drawing.Point(275, 28);
            this.LeftClickerEnableSwitch.Name = "LeftClickerEnableSwitch";
            this.LeftClickerEnableSwitch.Size = new System.Drawing.Size(40, 18);
            this.LeftClickerEnableSwitch.TabIndex = 12;
            this.LeftClickerEnableSwitch.Text = "dp";
            this.LeftClickerEnableSwitch.UseVisualStyleBackColor = true;
            // 
            // LeftClickerEnableLabel
            // 
            this.LeftClickerEnableLabel.AutoSize = true;
            this.LeftClickerEnableLabel.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeftClickerEnableLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.LeftClickerEnableLabel.Location = new System.Drawing.Point(8, 28);
            this.LeftClickerEnableLabel.Name = "LeftClickerEnableLabel";
            this.LeftClickerEnableLabel.Size = new System.Drawing.Size(48, 16);
            this.LeftClickerEnableLabel.TabIndex = 11;
            this.LeftClickerEnableLabel.Text = "Enable";
            // 
            // LeftClickerToggleKeyButton
            // 
            this.LeftClickerToggleKeyButton.BorderColor = System.Drawing.Color.Transparent;
            this.LeftClickerToggleKeyButton.BorderRadius = 2;
            this.LeftClickerToggleKeyButton.BorderThickness = 2;
            this.LeftClickerToggleKeyButton.CheckedState.Parent = this.LeftClickerToggleKeyButton;
            this.LeftClickerToggleKeyButton.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.LeftClickerToggleKeyButton.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.LeftClickerToggleKeyButton.CustomImages.Parent = this.LeftClickerToggleKeyButton;
            this.LeftClickerToggleKeyButton.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.LeftClickerToggleKeyButton.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.LeftClickerToggleKeyButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.LeftClickerToggleKeyButton.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.LeftClickerToggleKeyButton.HoverState.Parent = this.LeftClickerToggleKeyButton;
            this.LeftClickerToggleKeyButton.Location = new System.Drawing.Point(273, 144);
            this.LeftClickerToggleKeyButton.Name = "LeftClickerToggleKeyButton";
            this.LeftClickerToggleKeyButton.ShadowDecoration.Parent = this.LeftClickerToggleKeyButton;
            this.LeftClickerToggleKeyButton.Size = new System.Drawing.Size(46, 25);
            this.LeftClickerToggleKeyButton.TabIndex = 3;
            this.LeftClickerToggleKeyButton.Text = "None";
            // 
            // dopeGroupBox1
            // 
            this.dopeGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.dopeGroupBox1.Controls.Add(this.label1);
            this.dopeGroupBox1.Controls.Add(this.label2);
            this.dopeGroupBox1.Controls.Add(this.label3);
            this.dopeGroupBox1.Controls.Add(this.label4);
            this.dopeGroupBox1.Controls.Add(this.label5);
            this.dopeGroupBox1.Controls.Add(this.label6);
            this.dopeGroupBox1.Controls.Add(this.label7);
            this.dopeGroupBox1.Controls.Add(this.label8);
            this.dopeGroupBox1.Controls.Add(this.guna2CustomCheckBox1);
            this.dopeGroupBox1.Controls.Add(this.guna2CustomCheckBox2);
            this.dopeGroupBox1.Controls.Add(this.guna2CustomCheckBox3);
            this.dopeGroupBox1.Controls.Add(this.guna2CustomCheckBox4);
            this.dopeGroupBox1.Controls.Add(this.guna2CustomCheckBox5);
            this.dopeGroupBox1.Controls.Add(this.guna2CustomCheckBox6);
            this.dopeGroupBox1.Controls.Add(this.guna2CustomCheckBox7);
            this.dopeGroupBox1.Controls.Add(this.guna2CustomCheckBox8);
            this.dopeGroupBox1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dopeGroupBox1.Location = new System.Drawing.Point(13, 196);
            this.dopeGroupBox1.Name = "dopeGroupBox1";
            this.dopeGroupBox1.Size = new System.Drawing.Size(325, 242);
            this.dopeGroupBox1.TabIndex = 3;
            this.dopeGroupBox1.TabStop = false;
            this.dopeGroupBox1.Text = "Global Options";
            this.dopeGroupBox1.TitleFont = new System.Drawing.Font("Arial", 10F);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label1.Location = new System.Drawing.Point(32, 184);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 16);
            this.label1.TabIndex = 17;
            this.label1.Text = "Blockhit";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label2.Location = new System.Drawing.Point(32, 210);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 16);
            this.label2.TabIndex = 16;
            this.label2.Text = "Slots";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label3.Location = new System.Drawing.Point(32, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 16);
            this.label3.TabIndex = 15;
            this.label3.Text = "Click sounds";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label4.Location = new System.Drawing.Point(32, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 16);
            this.label4.TabIndex = 14;
            this.label4.Text = "Blatant mode";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label5.Location = new System.Drawing.Point(32, 106);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Only while playing";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label6.Location = new System.Drawing.Point(32, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "Allow when shifting";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label7.Location = new System.Drawing.Point(32, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(126, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "First click protection";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label8.Location = new System.Drawing.Point(32, 28);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 16);
            this.label8.TabIndex = 10;
            this.label8.Text = "Cps Drop";
            // 
            // guna2CustomCheckBox1
            // 
            this.guna2CustomCheckBox1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox1.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox1.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox1.CheckedState.Parent = this.guna2CustomCheckBox1;
            this.guna2CustomCheckBox1.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox1.Location = new System.Drawing.Point(6, 208);
            this.guna2CustomCheckBox1.Name = "guna2CustomCheckBox1";
            this.guna2CustomCheckBox1.ShadowDecoration.Parent = this.guna2CustomCheckBox1;
            this.guna2CustomCheckBox1.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox1.TabIndex = 9;
            this.guna2CustomCheckBox1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox1.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox1.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox1.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox1.UncheckedState.Parent = this.guna2CustomCheckBox1;
            // 
            // guna2CustomCheckBox2
            // 
            this.guna2CustomCheckBox2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox2.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox2.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox2.CheckedState.Parent = this.guna2CustomCheckBox2;
            this.guna2CustomCheckBox2.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox2.Location = new System.Drawing.Point(6, 182);
            this.guna2CustomCheckBox2.Name = "guna2CustomCheckBox2";
            this.guna2CustomCheckBox2.ShadowDecoration.Parent = this.guna2CustomCheckBox2;
            this.guna2CustomCheckBox2.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox2.TabIndex = 8;
            this.guna2CustomCheckBox2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox2.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox2.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox2.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox2.UncheckedState.Parent = this.guna2CustomCheckBox2;
            // 
            // guna2CustomCheckBox3
            // 
            this.guna2CustomCheckBox3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox3.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox3.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox3.CheckedState.Parent = this.guna2CustomCheckBox3;
            this.guna2CustomCheckBox3.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox3.Location = new System.Drawing.Point(6, 156);
            this.guna2CustomCheckBox3.Name = "guna2CustomCheckBox3";
            this.guna2CustomCheckBox3.ShadowDecoration.Parent = this.guna2CustomCheckBox3;
            this.guna2CustomCheckBox3.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox3.TabIndex = 7;
            this.guna2CustomCheckBox3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox3.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox3.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox3.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox3.UncheckedState.Parent = this.guna2CustomCheckBox3;
            // 
            // guna2CustomCheckBox4
            // 
            this.guna2CustomCheckBox4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox4.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox4.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox4.CheckedState.Parent = this.guna2CustomCheckBox4;
            this.guna2CustomCheckBox4.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox4.Location = new System.Drawing.Point(6, 130);
            this.guna2CustomCheckBox4.Name = "guna2CustomCheckBox4";
            this.guna2CustomCheckBox4.ShadowDecoration.Parent = this.guna2CustomCheckBox4;
            this.guna2CustomCheckBox4.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox4.TabIndex = 6;
            this.guna2CustomCheckBox4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox4.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox4.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox4.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox4.UncheckedState.Parent = this.guna2CustomCheckBox4;
            // 
            // guna2CustomCheckBox5
            // 
            this.guna2CustomCheckBox5.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox5.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox5.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox5.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox5.CheckedState.Parent = this.guna2CustomCheckBox5;
            this.guna2CustomCheckBox5.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox5.Location = new System.Drawing.Point(6, 104);
            this.guna2CustomCheckBox5.Name = "guna2CustomCheckBox5";
            this.guna2CustomCheckBox5.ShadowDecoration.Parent = this.guna2CustomCheckBox5;
            this.guna2CustomCheckBox5.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox5.TabIndex = 5;
            this.guna2CustomCheckBox5.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox5.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox5.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox5.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox5.UncheckedState.Parent = this.guna2CustomCheckBox5;
            // 
            // guna2CustomCheckBox6
            // 
            this.guna2CustomCheckBox6.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox6.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox6.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox6.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox6.CheckedState.Parent = this.guna2CustomCheckBox6;
            this.guna2CustomCheckBox6.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox6.Location = new System.Drawing.Point(6, 78);
            this.guna2CustomCheckBox6.Name = "guna2CustomCheckBox6";
            this.guna2CustomCheckBox6.ShadowDecoration.Parent = this.guna2CustomCheckBox6;
            this.guna2CustomCheckBox6.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox6.TabIndex = 4;
            this.guna2CustomCheckBox6.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox6.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox6.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox6.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox6.UncheckedState.Parent = this.guna2CustomCheckBox6;
            // 
            // guna2CustomCheckBox7
            // 
            this.guna2CustomCheckBox7.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox7.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox7.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox7.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox7.CheckedState.Parent = this.guna2CustomCheckBox7;
            this.guna2CustomCheckBox7.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox7.Location = new System.Drawing.Point(6, 52);
            this.guna2CustomCheckBox7.Name = "guna2CustomCheckBox7";
            this.guna2CustomCheckBox7.ShadowDecoration.Parent = this.guna2CustomCheckBox7;
            this.guna2CustomCheckBox7.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox7.TabIndex = 3;
            this.guna2CustomCheckBox7.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox7.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox7.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox7.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox7.UncheckedState.Parent = this.guna2CustomCheckBox7;
            // 
            // guna2CustomCheckBox8
            // 
            this.guna2CustomCheckBox8.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox8.CheckedState.BorderRadius = 1;
            this.guna2CustomCheckBox8.CheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox8.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox8.CheckedState.Parent = this.guna2CustomCheckBox8;
            this.guna2CustomCheckBox8.CheckMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(115)))), ((int)(((byte)(114)))), ((int)(((byte)(121)))));
            this.guna2CustomCheckBox8.Location = new System.Drawing.Point(6, 26);
            this.guna2CustomCheckBox8.Name = "guna2CustomCheckBox8";
            this.guna2CustomCheckBox8.ShadowDecoration.Parent = this.guna2CustomCheckBox8;
            this.guna2CustomCheckBox8.Size = new System.Drawing.Size(20, 20);
            this.guna2CustomCheckBox8.TabIndex = 2;
            this.guna2CustomCheckBox8.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2CustomCheckBox8.UncheckedState.BorderRadius = 2;
            this.guna2CustomCheckBox8.UncheckedState.BorderThickness = 2;
            this.guna2CustomCheckBox8.UncheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2CustomCheckBox8.UncheckedState.Parent = this.guna2CustomCheckBox8;
            // 
            // dopeGroupBox2
            // 
            this.dopeGroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.dopeGroupBox2.Controls.Add(this.dopeSwitch1);
            this.dopeGroupBox2.Controls.Add(this.label9);
            this.dopeGroupBox2.Controls.Add(this.guna2Button1);
            this.dopeGroupBox2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dopeGroupBox2.Location = new System.Drawing.Point(359, 12);
            this.dopeGroupBox2.Name = "dopeGroupBox2";
            this.dopeGroupBox2.Size = new System.Drawing.Size(325, 175);
            this.dopeGroupBox2.TabIndex = 2;
            this.dopeGroupBox2.TabStop = false;
            this.dopeGroupBox2.Text = "Right clicker";
            this.dopeGroupBox2.TitleFont = new System.Drawing.Font("Arial", 10F);
            // 
            // dopeSwitch1
            // 
            this.dopeSwitch1.AutoSize = true;
            this.dopeSwitch1.Location = new System.Drawing.Point(275, 28);
            this.dopeSwitch1.Name = "dopeSwitch1";
            this.dopeSwitch1.Size = new System.Drawing.Size(40, 18);
            this.dopeSwitch1.TabIndex = 14;
            this.dopeSwitch1.Text = "dp";
            this.dopeSwitch1.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label9.Location = new System.Drawing.Point(6, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 16);
            this.label9.TabIndex = 13;
            this.label9.Text = "Enable";
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderRadius = 2;
            this.guna2Button1.BorderThickness = 2;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2Button1.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.guna2Button1.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(273, 144);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(46, 25);
            this.guna2Button1.TabIndex = 4;
            this.guna2Button1.Text = "None";
            // 
            // dd
            // 
            this.dd.BackColor = System.Drawing.Color.Transparent;
            this.dd.Controls.Add(this.dopeSwitch2);
            this.dd.Controls.Add(this.label10);
            this.dd.Controls.Add(this.guna2Button2);
            this.dd.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dd.Location = new System.Drawing.Point(13, 12);
            this.dd.Name = "dd";
            this.dd.Size = new System.Drawing.Size(325, 175);
            this.dd.TabIndex = 1;
            this.dd.TabStop = false;
            this.dd.Text = "Profiles";
            this.dd.TitleFont = new System.Drawing.Font("Arial", 10F);
            // 
            // dopeSwitch2
            // 
            this.dopeSwitch2.AutoSize = true;
            this.dopeSwitch2.Location = new System.Drawing.Point(275, 28);
            this.dopeSwitch2.Name = "dopeSwitch2";
            this.dopeSwitch2.Size = new System.Drawing.Size(40, 18);
            this.dopeSwitch2.TabIndex = 12;
            this.dopeSwitch2.Text = "dp";
            this.dopeSwitch2.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(188)))), ((int)(((byte)(188)))));
            this.label10.Location = new System.Drawing.Point(8, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 16);
            this.label10.TabIndex = 11;
            this.label10.Text = "Enable";
            // 
            // guna2Button2
            // 
            this.guna2Button2.BorderColor = System.Drawing.Color.Transparent;
            this.guna2Button2.BorderRadius = 2;
            this.guna2Button2.BorderThickness = 2;
            this.guna2Button2.CheckedState.Parent = this.guna2Button2;
            this.guna2Button2.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(45)))), ((int)(((byte)(58)))));
            this.guna2Button2.CustomBorderThickness = new System.Windows.Forms.Padding(2);
            this.guna2Button2.CustomImages.Parent = this.guna2Button2;
            this.guna2Button2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(30)))), ((int)(((byte)(41)))));
            this.guna2Button2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(124)))), ((int)(((byte)(134)))));
            this.guna2Button2.HoverState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(52)))), ((int)(((byte)(62)))));
            this.guna2Button2.HoverState.Parent = this.guna2Button2;
            this.guna2Button2.Location = new System.Drawing.Point(273, 144);
            this.guna2Button2.Name = "guna2Button2";
            this.guna2Button2.ShadowDecoration.Parent = this.guna2Button2;
            this.guna2Button2.Size = new System.Drawing.Size(46, 25);
            this.guna2Button2.TabIndex = 3;
            this.guna2Button2.Text = "None";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(35)))), ((int)(((byte)(46)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.SideBarDelimiterPanel);
            this.Controls.Add(this.SideBarPanel);
            this.Controls.Add(this.SettingsPanel);
            this.Controls.Add(this.AutoclickerPanel);
            this.Controls.Add(this.ProfilesPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.SideBarPanel.ResumeLayout(false);
            this.SideBarPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LogoPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SettingsButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProfilesButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AutoclickerButton)).EndInit();
            this.AutoclickerPanel.ResumeLayout(false);
            this.ProfilesPanel.ResumeLayout(false);
            this.SettingsPanel.ResumeLayout(false);
            this.dopeGroupBox3.ResumeLayout(false);
            this.dopeGroupBox3.PerformLayout();
            this.dopeGroupBox4.ResumeLayout(false);
            this.dopeGroupBox4.PerformLayout();
            this.dopeGroupBox5.ResumeLayout(false);
            this.dopeGroupBox5.PerformLayout();
            this.GlobalOptionsGroupBox.ResumeLayout(false);
            this.GlobalOptionsGroupBox.PerformLayout();
            this.RightClickerGroupBox.ResumeLayout(false);
            this.RightClickerGroupBox.PerformLayout();
            this.LeftClickerGroupBox.ResumeLayout(false);
            this.LeftClickerGroupBox.PerformLayout();
            this.dopeGroupBox1.ResumeLayout(false);
            this.dopeGroupBox1.PerformLayout();
            this.dopeGroupBox2.ResumeLayout(false);
            this.dopeGroupBox2.PerformLayout();
            this.dd.ResumeLayout(false);
            this.dd.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel SideBarPanel;
        private System.Windows.Forms.Panel SideBarDelimiterPanel;
        private System.Windows.Forms.Panel AutoclickerPanel;
        private Dope.Clicker.Controls.DopeGroupBox RightClickerGroupBox;
        private Dope.Clicker.Controls.DopeGroupBox LeftClickerGroupBox;
        private Dope.Clicker.Controls.DopeGroupBox GlobalOptionsGroupBox;
        private Guna.UI2.WinForms.Guna2CustomCheckBox CpsDropCheckBox;
        private Guna.UI2.WinForms.Guna2CustomCheckBox SlotsCheckBox;
        private Guna.UI2.WinForms.Guna2CustomCheckBox BlockhitCheckBox;
        private Guna.UI2.WinForms.Guna2CustomCheckBox ClickSoundsCheckBox;
        private Guna.UI2.WinForms.Guna2CustomCheckBox BlatantModeCheckBox;
        private Guna.UI2.WinForms.Guna2CustomCheckBox OnlyWhilePlayingCheckBox;
        private Guna.UI2.WinForms.Guna2CustomCheckBox AllowWhenShiftingCheckBox;
        private Guna.UI2.WinForms.Guna2CustomCheckBox FirstClickProtectionCheckBox;
        private System.Windows.Forms.Label CpsDropLabel;
        private System.Windows.Forms.Label FirstClickProtectionLabel;
        private System.Windows.Forms.Label AllowWhenShiftingLabel;
        private System.Windows.Forms.Label OnlyWhilePlayingLabel;
        private System.Windows.Forms.Label BlatantModeLabel;
        private System.Windows.Forms.Label ClickSoundsLabel;
        private System.Windows.Forms.Label SlotsLabel;
        private System.Windows.Forms.Label BlockhitLabel;
        private Guna.UI2.WinForms.Guna2Button LeftClickerToggleKeyButton;
        private Guna.UI2.WinForms.Guna2Button RightClickerToggleKeyButton;
        private System.Windows.Forms.Label LeftClickerEnableLabel;
        private Dope.Clicker.Controls.DopeSwitch LeftClickerEnableSwitch;
        private Dope.Clicker.Controls.DopeSwitch RightClickerEnableSwitch;
        private System.Windows.Forms.Label RightClickerEnableLabel;
        private Guna.UI2.WinForms.Guna2Button CloseButton;
        private Guna.UI2.WinForms.Guna2Button MinimizeButton;
        private System.Windows.Forms.PictureBox AutoclickerButton;
        private System.Windows.Forms.PictureBox SettingsButton;
        private System.Windows.Forms.PictureBox ProfilesButton;
        private System.Windows.Forms.PictureBox LogoPictureBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LicensedToLabel;
        private System.Windows.Forms.Label UsernameLabel;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel ProfilesPanel;
        private Dope.Clicker.Controls.DopeGroupBox dopeGroupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox1;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox2;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox3;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox4;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox5;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox6;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox7;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox8;
        private Dope.Clicker.Controls.DopeGroupBox dopeGroupBox2;
        private Dope.Clicker.Controls.DopeSwitch dopeSwitch1;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Dope.Clicker.Controls.DopeGroupBox dd;
        private Dope.Clicker.Controls.DopeSwitch dopeSwitch2;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2Button guna2Button2;
        private System.Windows.Forms.Panel SettingsPanel;
        private Dope.Clicker.Controls.DopeGroupBox dopeGroupBox3;
        private Dope.Clicker.Controls.DopeGroupBox dopeGroupBox4;
        private Dope.Clicker.Controls.DopeSwitch dopeSwitch3;
        private System.Windows.Forms.Label label19;
        private Guna.UI2.WinForms.Guna2Button guna2Button3;
        private Dope.Clicker.Controls.DopeGroupBox dopeGroupBox5;
        private Dope.Clicker.Controls.DopeSwitch dopeSwitch4;
        private System.Windows.Forms.Label label20;
        private Guna.UI2.WinForms.Guna2Button guna2Button4;
        private Guna.UI2.WinForms.Guna2Button Slot9Button;
        private Guna.UI2.WinForms.Guna2Button Slot8Button;
        private Guna.UI2.WinForms.Guna2Button Slot7Button;
        private Guna.UI2.WinForms.Guna2Button Slot6Button;
        private Guna.UI2.WinForms.Guna2Button Slot5Button;
        private Guna.UI2.WinForms.Guna2Button Slot4Button;
        private Guna.UI2.WinForms.Guna2Button Slot3Button;
        private Guna.UI2.WinForms.Guna2Button Slot2Button;
        private Guna.UI2.WinForms.Guna2Button Slot1Button;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox17;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox13;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox14;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox15;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox16;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox12;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox11;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox10;
        private Guna.UI2.WinForms.Guna2CustomCheckBox guna2CustomCheckBox9;
        private System.Windows.Forms.Label SlotSelectionLabel;
    }
}