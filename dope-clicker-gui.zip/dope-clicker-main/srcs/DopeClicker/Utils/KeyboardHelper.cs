﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DopeClicker.Utils {
    static class KeyboardHelper {
        public static string FormatKey(Keys key) {
            string keyStr = key.ToString();

            if (keyStr.Length == 2 && keyStr[0] == 'D' && int.TryParse(
                keyStr[1].ToString(), out int result)) {
                return result.ToString();
            }
            else if (keyStr.EndsWith("Key")) {
                return keyStr.Split(new string[] { "Key" }, StringSplitOptions.None)[0];
            }

            return keyStr;
        }
    }
}
