﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DopeClicker.Utils {
    static class ControlHelper {
        public static void CenterControl(Control control) {
            control.Left = (control.Parent.ClientSize.Width - control.Size.Width) / 2;
            if (control.Focused) control.Focus();
        }
    }
}
