﻿using System;
using System.Runtime.InteropServices;

namespace DopeClicker.Utils {
    static class WinApi {
        public static class Structs {
            [StructLayout(LayoutKind.Sequential)]
            public struct POINT {
                public int x;
                public int y;
            }
            [StructLayout(LayoutKind.Sequential)]
            public struct CURSORINFO {
                public int cbSize;
                public int flags;
                public IntPtr hCursor;
                public POINT ptScreenPos;
            }
        }
        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint uMilliseconds);
        [DllImport("user32.dll")]
        public static extern bool GetAsyncKeyState(int vk_code);
        [DllImport("user32.dll")]
        public static extern bool GetCursorInfo(ref Structs.CURSORINFO pci);
        [DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int wMsg, int wParam, int lParam);
        
    }
}
