﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DopeClicker.Utils {
    static class ProcessHelper {
        public static bool ProcessIsAlive(int id) {
            try {
                return Process.GetProcessById(id) != null;
            }
            catch {
                return false;
            }
        }

        public static bool ProcessIsAlive(Process process) {
            return ProcessIsAlive(process.Id);
        }
    }
}
