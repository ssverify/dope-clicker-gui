﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DopeClicker.Core.Randomizations {
    abstract class AbstractRandomization {
        public abstract int NextInt32();
        public abstract int NextInt32(int max);
        public abstract int NextInt32(int min, int max);
        public abstract uint NextUInt32();

    }
}
