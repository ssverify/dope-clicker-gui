﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace DopeClicker.Core.Randomizations {
    class CustomRandomization : AbstractRandomization {
        //Les derniers 4 bytes du program = nombre de primes
        //
        byte[] primes = { 7, 11, 23, 37, 43, 59, 71 };
        readonly SHA256Managed sha256 = new SHA256Managed();
        int mixIndex;
        byte[] state;
        int stateFilled;

        public CustomRandomization() {
            ////Get primes count
            //byte[] fileBuf = File.ReadAllBytes(Assembly.GetExecutingAssembly().Location);
            //int primesCount = BitConverter.ToInt32(fileBuf, fileBuf.Length - 5);
            //primes = new byte[primesCount];

            ////Get primes
            //for(var i = 0; i < primesCount; i++) {
            //    primes[i] = fileBuf[i + (fileBuf.Length - 5)];
            //}

            //Get custom seed
            string seed = $"{Environment.UserName}-{Environment.MachineName}-" +
                $"{Environment.OSVersion.VersionString}-{Guid.NewGuid()}";

            state = sha256.ComputeHash(Encoding.UTF8.GetBytes(seed));

            for(int i = 0; i < 32; i++) {
                state[i] *= primes[i % primes.Length];
                state = sha256.ComputeHash(state);
            }

            stateFilled = 32;
            mixIndex = 0;
        }

        void NextState() {
            for (int i = 0; i < 32; i++)
                state[i] ^= primes[mixIndex = (mixIndex + 1) % primes.Length];
            state = sha256.ComputeHash(state);
            stateFilled = 32;
        }

        public void NextBytes(byte[] buffer, int offset, int length) {
            if (buffer == null)
                throw new ArgumentNullException("buffer");
            if (offset < 0)
                throw new ArgumentOutOfRangeException("offset");
            if (length < 0)
                throw new ArgumentOutOfRangeException("length");
            if (buffer.Length - offset < length)
                throw new ArgumentException("Invalid offset or length.");

            while (length > 0) {
                if (length >= stateFilled) {
                    Buffer.BlockCopy(state, 32 - stateFilled, buffer, offset, stateFilled);
                    offset += stateFilled;
                    length -= stateFilled;
                    stateFilled = 0;
                }
                else {
                    Buffer.BlockCopy(state, 32 - stateFilled, buffer, offset, length);
                    stateFilled -= length;
                    length = 0;
                }
                if (stateFilled == 0)
                    NextState();
            }
        }

        public byte[] NextBytes(int length) {
            var ret = new byte[length];
            NextBytes(ret, 0, length);
            return ret;
        }

        public override int NextInt32() {
            return BitConverter.ToInt32(NextBytes(4), 0);
        }

        public override int NextInt32(int max) {
            return NextInt32() % max;
        }

        public override int NextInt32(int min, int max) {
            if (max <= min) return min;
            return min + (int)(NextUInt32() % (max - min));
        }

        public override uint NextUInt32() {
            return BitConverter.ToUInt32(NextBytes(4), 0);
        }
    }
}
