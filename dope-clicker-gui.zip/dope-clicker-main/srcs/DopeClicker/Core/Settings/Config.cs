﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DopeClicker.Core.Settings {
    class Config {
        public Slot[] Slots { get; set; }

        public static Config Default = new Config() {
            Slots = new Slot[] {
                new Slot() {Key = Keys.D1, Enable = false },
                new Slot() {Key = Keys.D2, Enable = false },
                new Slot() {Key = Keys.D3, Enable = false },
                new Slot() {Key = Keys.D4, Enable = false },
                new Slot() {Key = Keys.D5, Enable = false },
                new Slot() {Key = Keys.D6, Enable = false },
                new Slot() {Key = Keys.D7, Enable = false },
                new Slot() {Key = Keys.D8, Enable = false },
                new Slot() {Key = Keys.D9, Enable = false },

            }
        };
    }
}
