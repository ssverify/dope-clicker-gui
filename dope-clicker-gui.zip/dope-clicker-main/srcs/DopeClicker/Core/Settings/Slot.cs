﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DopeClicker.Core.Settings {
    class Slot {
        public Keys Key { get; set; }
        public bool Enable { get; set; }
    }
}
