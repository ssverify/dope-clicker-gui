﻿using DopeClicker.Utils;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DopeClicker.Core {
    class Minecraft {
        Process process;

        public Minecraft(Process process) {
            this.process = process;
        }

        public bool IsAlive() {
            return ProcessHelper.ProcessIsAlive(this.process.Id);
        }

        public bool IsInGame() {
            WinApi.Structs.CURSORINFO pci = default(WinApi.Structs.CURSORINFO);
            pci.cbSize = Marshal.SizeOf(typeof(WinApi.Structs.CURSORINFO));
            WinApi.GetCursorInfo(ref pci);
            return pci.flags != 1;
        }

        public void DoLeftClick(int delay) {
            WinApi.SendMessage(this.process.MainWindowHandle, 0x201, 0, 0);
            Thread.Sleep(delay);
            WinApi.SendMessage(this.process.MainWindowHandle, 0x202, 0, 0);
        }

        public void DoRightClick(int delay) {
            WinApi.SendMessage(this.process.MainWindowHandle, 0x204, 0, 0);
            Thread.Sleep(delay);
            WinApi.SendMessage(this.process.MainWindowHandle, 0x205, 0, 0);
        }
    }
}
